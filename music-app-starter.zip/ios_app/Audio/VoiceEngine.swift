import AVFoundation

class VoiceEngine {
    private let engine = AVAudioEngine()

    init() {
        // TODO: configure AVAudioSession, attach AUv3 nodes from dsp_core
    }

    func startRecording() {
        // TODO: install tap on main mixer node, write to file
    }

    func stopRecording() {
        // TODO: stop tap and close file
    }
}

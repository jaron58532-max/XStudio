import SwiftUI

struct RecordView: View {
    @State private var isRecording = false

    var body: some View {
        VStack {
            Spacer()
            Button(action: toggleRecord) {
                Circle()
                    .fill(isRecording ? Color.red : Color.gray)
                    .frame(width: 100, height: 100)
                    .overlay(Text(isRecording ? "Stop" : "Rec").foregroundColor(.white))
            }
            Spacer()
        }
    }

    func toggleRecord() {
        isRecording.toggle()
        // TODO: hook into VoiceEngine.startRecording() / stopRecording()
    }
}

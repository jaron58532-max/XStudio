#include "catch.hpp"
#include "../dsp_core/AudioEngine.h"

TEST_CASE("AudioEngine processes silence") {
    AudioEngine engine;
    engine.prepareToPlay(44100.0, 512);

    juce::AudioBuffer<float> buffer(2, 512);
    buffer.clear();
    engine.processBlock(buffer);

    REQUIRE(buffer.getNumSamples() == 512);
}

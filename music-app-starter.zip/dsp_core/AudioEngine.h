#pragma once
#include <juce_audio_processors/juce_audio_processors.h>

class AudioEngine {
public:
    AudioEngine();
    ~AudioEngine();

    void prepareToPlay(double sampleRate, int samplesPerBlock);
    void processBlock(juce::AudioBuffer<float>& buffer);
    void releaseResources();

private:
    juce::AudioProcessorGraph graph;
    void buildGraph();
};

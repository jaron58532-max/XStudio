import SwiftUI

@main
struct MusicApp: App {
    var body: some Scene {
        WindowGroup {
            Text("Hello MusicApp!")
        }
    }
}

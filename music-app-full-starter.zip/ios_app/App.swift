import SwiftUI

@main
struct MusicApp: App {
    var body: some Scene {
        WindowGroup {
            TabView {
                RecordView().tabItem { Label("Record", systemImage: "mic") }
                BeatsView().tabItem { Label("Beats", systemImage: "music.note.list") }
                LyricsView().tabItem { Label("Lyrics", systemImage: "text.quote") }
                MixView().tabItem { Label("Mix", systemImage: "slider.horizontal.3") }
            }
        }
    }
}

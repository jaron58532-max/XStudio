#include "AudioEngine.h"
#include "Effects/NoiseSuppressor.h"

AudioEngine::AudioEngine() { buildGraph(); }
AudioEngine::~AudioEngine() {}

void AudioEngine::prepareToPlay(double sampleRate, int samplesPerBlock) {
    graph.setPlayConfigDetails(2, 2, sampleRate, samplesPerBlock);
    graph.prepareToPlay(sampleRate, samplesPerBlock);
}

void AudioEngine::processBlock(juce::AudioBuffer<float>& buffer) {
    juce::MidiBuffer midi;
    graph.processBlock(buffer, midi);
}

void AudioEngine::releaseResources() { graph.releaseResources(); }

void AudioEngine::buildGraph() {
    // TODO: add and connect processor nodes here
}

#pragma once
#include <juce_audio_processors/juce_audio_processors.h>

class NoiseSuppressor : public juce::AudioProcessor {
public:
    NoiseSuppressor();
    ~NoiseSuppressor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    const juce::String getName() const override { return "NoiseSuppressor"; }
    double getTailLengthSeconds() const override { return 0.0; }
};

#include "NoiseSuppressor.h"

NoiseSuppressor::NoiseSuppressor() {}
void NoiseSuppressor::prepareToPlay(double, int) {}
void NoiseSuppressor::releaseResources() {}

void NoiseSuppressor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) {
    // TODO: integrate RNNoise or spectral gating here
}

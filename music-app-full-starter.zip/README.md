# MusicApp

Cross-platform music recording app (iOS + Windows) with beats, lyric assist, and auto mix/master.
